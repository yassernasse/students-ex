let teachers = [
    { email: "teacher@example.com", password: "123456", name: "?. ????" },
    { email: "teacher2@example.com", password: "654321", name: "?. ?????" }
];

let students = JSON.parse(localStorage.getItem("students")) || [];
let maxOutLimit = parseInt(localStorage.getItem("maxOutLimit")) || 6;
let currentOut = 0;

// ????? ?????? ?? ????? ?????
function login() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    let teacher = teachers.find(t => t.email === email && t.password === password);
    if (teacher) {
        document.getElementById("login-screen").style.display = "none";
        document.getElementById("app").style.display = "block";
        document.getElementById("welcome-message").innerText = `?????? ??? ${teacher.name} ??`;
        renderStudents();
    } else {
        alert("?????? ?????? ??? ?????");
    }
}

// ????? ???? ?????? ?????? ???????
function updateMaxLimit() {
    maxOutLimit = parseInt(document.getElementById("max-out-limit").value);
    localStorage.setItem("maxOutLimit", maxOutLimit);
    alert("?? ????? ???? ??????");
}

// ????? ???? ????
function addStudent() {
    let name = document.getElementById("student-name").value;
    if (name) {
        students.push({ name, outCount: 0, isOut: false });
        localStorage.setItem("students", JSON.stringify(students));
        document.getElementById("student-name").value = "";
        renderStudents();
    }
}

// ???? ????
function studentOut(index) {
    if (students[index].outCount < 3 && currentOut < maxOutLimit) {
        students[index].outCount++;
        students[index].isOut = true;
        currentOut++;
        localStorage.setItem("students", JSON.stringify(students));
        renderStudents();
    } else {
        alert("?? ???? ?????? ?????? ???? ?? 3 ???? ?? ???? ?????? ?????!");
    }
}

// ???? ????
function studentReturn(index) {
    students[index].isOut = false;
    currentOut--;
    localStorage.setItem("students", JSON.stringify(students));
    renderStudents();
    alert("???? ???? ???? ????? ???? ????!");
}

// ??? ????? ??????
function renderStudents() {
    let list = document.getElementById("student-list");
    list.innerHTML = "";

    students.forEach((student, index) => {
        let li = document.createElement("li");
        li.innerHTML = `
            ${student.name} - ???? ??????: ${student.outCount}/3
            ${student.isOut ? `<button class="return-btn" onclick="studentReturn(${index})">????</button>` 
                            : `<button class="out-btn" onclick="studentOut(${index})">????</button>`}
        `;
        list.appendChild(li);
    });
}

// ????? ???????? ??? ????? ???????
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("max-out-limit").value = maxOutLimit;
    renderStudents();
});
